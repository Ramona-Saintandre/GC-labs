'use strict'
/**
 * Ramona Saintandre 
 * November 18th, 2019
 * GC - JSLab2 - functionality of Game
 *    
 */

 fight ();